importScripts('workbox-sw.prod.v2.0.0.js');

const workboxSW = new self.WorkboxSW();
workboxSW.precache([]);